<?php
/**
 * Multimedijalni Sistemi child theme functions and definitions.
 *
 * Add your custom PHP in this file.
 * Only edit this file if you have direct access to it on your server (to fix errors if they happen).
 */

 function enqueue_styles() {
	
	// enqueue parent styles
	wp_enqueue_style('multimedijalni-sistemi', get_template_directory_uri() .'/style.css');
	
}
add_action('wp_enqueue_scripts', 'enqueue_styles');
